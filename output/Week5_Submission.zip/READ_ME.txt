WEEK 5 SUBMISSION - FOOD BUDGET ATLAS

The primary document is Week5_Proposal.pdf. It contains the dataset selection, three research questions, three layout sketches, and the six-column channel justification table.

The supporting folder contains the CSV extracts, an editable SVG of the three layouts, and source / AI-assistance documentation. These supporting files are optional unless the instructor requests them.

This package covers Week 5 only. It does not claim completion of peer testing, the Week 7 classroom feedback session, or the Week 8 final submission.
