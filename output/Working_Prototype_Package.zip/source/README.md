# Food Budget Atlas - Development source

The ready-to-use dashboard is `../Food_Budget_Atlas.html`. Double-click it after extracting the ZIP; no installation or network connection is needed.

## Edit and run

Use Node.js 22.12+ (or Node 20.19+). In this source directory:

```sh
npm ci
npm run dev
```

Open the local URL printed by Vite. Data are included under `data/`; no BLS key or live request is required. If the Windows npm cache is unwritable, append `--cache .npm-cache` to `npm ci`.

## Build and verify

```sh
npm run build:portable
python scripts/check_data.py
node scripts/check_prototype.mjs
```

The standalone output is `output/prototype/Food_Budget_Atlas.html`. Browser checks use a local Microsoft Edge installation through Playwright. The dashboard itself works in modern browsers and does not depend on Edge.

For a development server on port 4173, also run `node scripts/check_dashboard.mjs` and `node scripts/check_transitions.mjs`. Both accept a `DASHBOARD_URL` environment variable for other URLs or the standalone file.

To reproduce the submission documents after verification, run `node scripts/capture_prototype.mjs`, then `python scripts/build_prototype_package.py`. The PDF builder requires ReportLab and the Windows Georgia fonts.

## Source map

- `src/main.js`: shared state, calculations, three D3 views and interaction handling.
- `src/styles.css` and `index.html`: layout, accessibility labels and responsive styling.
- `data/`: frozen BLS raw response and both CSV representations.
- [Sources and AI assistance](docs/sources.md).
- [Working prototype rubric and evidence](docs/working-prototype.md).
- [Detailed layout](docs/prototype-layout.svg).
- [Final usability protocol](docs/usability-testing.md), still awaiting real peer sessions.

Three views answer the income-comparison, category-breakdown and historical-change questions. All percentages divide by total expenditures. Dot area always represents annual all-food dollars. Values are group means in current dollars, with no causal or individual-household interpretation.
